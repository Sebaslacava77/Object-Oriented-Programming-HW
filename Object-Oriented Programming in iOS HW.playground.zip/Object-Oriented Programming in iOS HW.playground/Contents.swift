//Exercise1

class Post {
    var author: String
    var content: String
    var likes: Int
    
    init(author: String, content: String, likes: Int) {
        self.author = author
        self.content = content
        self.likes = likes
    }
    
    func display() {
        print("Author: \(author)")
        print("Content: \(content)")
        print("Likes: \(likes)")
        print("----------------------")
    }
}

let post1 = Post(author: "Sebastian", content: "Hello, world!", likes: 12)
let post2 = Post(author: "Nico", content: "Swift is cool!", likes: 54)

post1.display()
post2.display()

class Product {
    var name: String
    var price: Double
    var quantity: Int
    
    init(name: String, price: Double, quantity: Int) {
        self.name = name
        self.price = price
        self.quantity = quantity
    }
    
}

//Exercise2

@MainActor
class ShoppingCartSingleton{
    static let sharedInstance = ShoppingCartSingleton()
    private var products: [Product] = []
    private init() {}
    
    func addProduct(product: Product, quantity: Int) {
        if let index = products.firstIndex(where: { $0.name == product.name }) {
            products[index].quantity += quantity
        } else {
            products.append(product)
        }
    }
    func removeProduct(product: Product) {
        products.removeAll { $0.name == product.name}
    }
    func clearCart() {
        products.removeAll()
    }
    func getTotalPrice() -> Double {
        var total: Double = 0
        for product in products {
            total += product.price * Double(product.quantity)
        }
        return total
    }
    func listCartContents() -> [Product] {
        for product in products {
            print("\(product.name): $\(product.price) x \(product.quantity)")
        }
        return products
    }
}

let cart = ShoppingCartSingleton.sharedInstance

let apple = Product(name: "Apple", price: 0.99, quantity: 3)
let banana = Product(name: "Banana", price: 0.59, quantity: 4)

cart.addProduct(product: apple, quantity: 3)
cart.addProduct(product: banana, quantity: 4)

cart.listCartContents()

print("Total Price: $\(cart.getTotalPrice())")

cart.removeProduct(product: apple)
print("Removed 3 apples from cart")
cart.listCartContents()

cart.clearCart()
print("Cart cleared.")
cart.listCartContents()


//Exercise3
enum PaymentError: Error {
    case insufficientFunds
    case invalidCard
    case unknownError
}

protocol PaymentProcessor {
    func processPayment(amount: Double) throws
}

class CreditCardPaymentProcessor: PaymentProcessor {
    var balance: Double
    var isValidCard: Bool

    init(balance: Double, isValidCard: Bool = true) {
        self.balance = balance
        self.isValidCard = isValidCard
    }
    
    func processPayment(amount: Double) throws {
        guard isValidCard else {
            throw PaymentError.invalidCard
        }
        guard amount <= balance else {
            throw PaymentError.insufficientFunds
        }
        balance -= amount
        print("Credit card payment of $\(amount) approved!")
    }
}

class CashProcessor: PaymentProcessor {
    var availableCash: Double
    
    init(availableCash: Double) {
        self.availableCash = availableCash
    }
    
    func processPayment(amount: Double) throws {
        guard amount <= availableCash else {
            throw PaymentError.insufficientFunds
        }
        
        availableCash -= amount
        print("Cash payment of $\(amount) approved!")
        
    }
}

let card = CreditCardPaymentProcessor(balance: 100, isValidCard: true)
let cash = CashProcessor(availableCash: 50)

do {
    try card.processPayment(amount: 100)
} catch PaymentError.invalidCard {
    print("Credit card is invalid.")
} catch PaymentError.insufficientFunds {
    print("Insufficient credit card funds.")
} catch {
    print("Unknown error: \(error)")
}

do {
    try cash.processPayment(amount: 60)
} catch PaymentError.insufficientFunds {
    print("Insufficient cash funds.")
} catch {
    print("Unknown error: \(error)")
}
